import Taro from '@tarojs/taro-h5';
import { Component } from "@tarojs/taro-h5";
import Nerv from "nervjs";
import { View, Text, Input } from '@tarojs/components';
import { AtButton, AtList, AtListItem } from 'taro-ui';
import { observer, inject } from "@tarojs/mobx-h5";
// function pay(){
//   if (process.env.TARO_ENV === 'weapp') {
//     require('微信支付接口')
//   } else if (process.env.TARO_ENV === 'alipay') {
//     // 编译的时候 只编译这个里面的代码
//     require('支付宝支付')
//   }
// }


// 注入我们需要的store

export default @inject('booksStore')
@observer
class Books extends Component {

  config = {
    navigationBarTitleText: '图书馆'
  };
  constructor(props) {
    super(props);
    this.state = {
      val: "",
      type: "h5"
    };
  }
  handleInput = e => {
    this.setState({
      val: e.target.value
    });
  };
  handleCilck = () => {
    // this.state.todos.push
    const { booksStore } = this.props;
    booksStore.addTodo(this.state.val);
    this.setState({
      val: ''
    });
  };
  handleChange = i => {
    const { booksStore } = this.props;
    booksStore.removeTodo(i);
  };
  render() {
    const { booksStore } = this.props;
    return <View>
      <Text>开课吧taro demo -- {this.state.type}</Text>
      <Input value={this.state.val} onChange={this.handleInput}></Input>
      <AtButton type="primary" loading onClick={this.handleCilck}>添加</AtButton>
      <AtList>

      {booksStore.todos.map((item, i) => {
          return <AtListItem title={i + ":" + item} isSwitch onSwitchChange={() => this.handleChange(i)}>
           
          </AtListItem>;
        })}
      </AtList>
      
      {/* {
         booksStore.todos.map((item,i)=>{
           return <View>
             <Text>{i+1} : {item}</Text>
           </View>
         })
        } */}
      {/* <AtCard
         note='小Tips'
         extra='额外信息'
         title='这是个标题'
         thumb='http://www.logoquan.com/upload/list/20180421/logoquan15259400209.PNG'
        >
         这也是内容区 可以随意定义功能
        </AtCard> */}

    </View>;
  }
}