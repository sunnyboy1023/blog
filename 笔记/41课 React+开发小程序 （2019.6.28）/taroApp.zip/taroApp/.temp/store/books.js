import Taro from '@tarojs/taro-h5';
import { observable } from 'mobx';
import Nerv from "nervjs";

// observable可以把普通对象，变成响应式， 写起来比dva要双一些，更像vuex

// 响应式数据源

let booksStore = observable({
  todos: ['吃饭', '睡觉', '学习taro'],
  addTodo(item) {
    this.todos.push(item);
  },
  removeTodo(i) {
    Taro.showLoading({
      title: '删除中'
    });
    setTimeout(() => {
      this.todos.splice(i, 1);
      Taro.hideLoading();
    }, 1000);
  }
});
export default booksStore;